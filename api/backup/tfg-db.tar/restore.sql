--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Debian 13.4-1.pgdg110+1)
-- Dumped by pg_dump version 13.4 (Debian 13.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "tfg-db";
--
-- Name: tfg-db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "tfg-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE "tfg-db" OWNER TO postgres;

\connect -reuse-previous=on "dbname='tfg-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: path_types; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.path_types AS ENUM (
    'technical',
    'cognitive',
    'values'
);


ALTER TYPE public.path_types OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paths (
    id integer NOT NULL,
    name jsonb NOT NULL,
    "desc" jsonb,
    type character varying NOT NULL,
    requirements jsonb DEFAULT '[]'::jsonb NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.paths OWNER TO postgres;

--
-- Name: COLUMN paths.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paths.name IS 'tranlation';


--
-- Name: COLUMN paths."desc"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paths."desc" IS 'tranlation';


--
-- Name: COLUMN paths.requirements; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.paths.requirements IS 'array of path ids';


--
-- Name: paths_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paths_id_seq OWNER TO postgres;

--
-- Name: paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paths_id_seq OWNED BY public.paths.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.questions (
    test_id integer,
    topic_id integer,
    "order" integer,
    text jsonb,
    timeout integer,
    answers jsonb,
    id integer NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.questions OWNER TO postgres;

--
-- Name: COLUMN questions.text; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.questions.text IS 'tranlation';


--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_id_seq OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resources (
    id integer NOT NULL,
    topic_id integer,
    name jsonb,
    url character varying,
    status character varying,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.resources OWNER TO postgres;

--
-- Name: COLUMN resources.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.resources.name IS 'tranlation';


--
-- Name: resources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resources_id_seq OWNER TO postgres;

--
-- Name: resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.resources_id_seq OWNED BY public.resources.id;


--
-- Name: table_name_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.table_name_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.table_name_id_seq OWNER TO postgres;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tests (
    dimentions jsonb,
    id integer NOT NULL,
    path_id integer,
    name jsonb,
    "desc" jsonb,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    questions_last date DEFAULT now() NOT NULL,
    questions_day integer DEFAULT 5 NOT NULL,
    key character varying
);


ALTER TABLE public.tests OWNER TO postgres;

--
-- Name: COLUMN tests.dimentions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tests.dimentions IS 'array of dimentions';


--
-- Name: COLUMN tests.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tests.name IS 'tranlation';


--
-- Name: COLUMN tests."desc"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tests."desc" IS 'tranlation';


--
-- Name: tests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tests_id_seq OWNER TO postgres;

--
-- Name: tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tests_id_seq OWNED BY public.tests.id;


--
-- Name: topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topics (
    topic_id integer NOT NULL,
    name jsonb,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.topics OWNER TO postgres;

--
-- Name: COLUMN topics.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.topics.name IS 'tranlation';


--
-- Name: topics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.topics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.topics_id_seq OWNER TO postgres;

--
-- Name: topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.topics_id_seq OWNED BY public.topics.topic_id;


--
-- Name: user_paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_paths (
    path_id integer NOT NULL,
    user_id integer NOT NULL,
    status character varying DEFAULT 'active'::character varying NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_paths OWNER TO postgres;

--
-- Name: user_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_questions (
    question_id integer NOT NULL,
    status character varying DEFAULT 'active'::character varying NOT NULL,
    answer jsonb,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL,
    skip_conditions jsonb DEFAULT '[]'::jsonb NOT NULL,
    skip_text json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public.user_questions OWNER TO postgres;

--
-- Name: COLUMN user_questions.skip_text; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.user_questions.skip_text IS 'translation';


--
-- Name: user_resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_resources (
    user_id integer NOT NULL,
    topic_id integer NOT NULL
);


ALTER TABLE public.user_resources OWNER TO postgres;

--
-- Name: user_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_test_id_seq OWNER TO postgres;

--
-- Name: user_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_tests (
    id integer NOT NULL,
    test_id integer,
    user_id integer,
    status character varying,
    acc_results jsonb DEFAULT '{}'::jsonb NOT NULL,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL,
    questions_today integer DEFAULT 0 NOT NULL,
    questions_day integer DEFAULT 5 NOT NULL
);


ALTER TABLE public.user_tests OWNER TO postgres;

--
-- Name: user_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_tests_id_seq OWNER TO postgres;

--
-- Name: user_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_tests_id_seq OWNED BY public.user_tests.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying,
    surname character varying,
    nickname character varying NOT NULL,
    lang character varying NOT NULL,
    initialized boolean DEFAULT false,
    created timestamp with time zone DEFAULT now() NOT NULL,
    updated timestamp with time zone DEFAULT now() NOT NULL,
    today_questions integer DEFAULT 5 NOT NULL,
    average_questions integer DEFAULT 5 NOT NULL,
    email character varying,
    password character varying DEFAULT ''::character varying NOT NULL,
    is_admin boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: paths id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paths ALTER COLUMN id SET DEFAULT nextval('public.paths_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: resources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resources ALTER COLUMN id SET DEFAULT nextval('public.resources_id_seq'::regclass);


--
-- Name: tests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests ALTER COLUMN id SET DEFAULT nextval('public.tests_id_seq'::regclass);


--
-- Name: topics topic_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topics ALTER COLUMN topic_id SET DEFAULT nextval('public.topics_id_seq'::regclass);


--
-- Name: user_tests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tests ALTER COLUMN id SET DEFAULT nextval('public.user_tests_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paths (id, name, "desc", type, requirements, created, updated) FROM stdin;
\.
COPY public.paths (id, name, "desc", type, requirements, created, updated) FROM '$$PATH$$/3123.dat';

--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.questions (test_id, topic_id, "order", text, timeout, answers, id, created, updated) FROM stdin;
\.
COPY public.questions (test_id, topic_id, "order", text, timeout, answers, id, created, updated) FROM '$$PATH$$/3125.dat';

--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resources (id, topic_id, name, url, status, created, updated) FROM stdin;
\.
COPY public.resources (id, topic_id, name, url, status, created, updated) FROM '$$PATH$$/3127.dat';

--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tests (dimentions, id, path_id, name, "desc", created, updated, priority, questions_last, questions_day, key) FROM stdin;
\.
COPY public.tests (dimentions, id, path_id, name, "desc", created, updated, priority, questions_last, questions_day, key) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.topics (topic_id, name, created, updated) FROM stdin;
\.
COPY public.topics (topic_id, name, created, updated) FROM '$$PATH$$/3132.dat';

--
-- Data for Name: user_paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_paths (path_id, user_id, status, created, updated) FROM stdin;
\.
COPY public.user_paths (path_id, user_id, status, created, updated) FROM '$$PATH$$/3134.dat';

--
-- Data for Name: user_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_questions (question_id, status, answer, test_id, user_id, created, updated, skip_conditions, skip_text) FROM stdin;
\.
COPY public.user_questions (question_id, status, answer, test_id, user_id, created, updated, skip_conditions, skip_text) FROM '$$PATH$$/3135.dat';

--
-- Data for Name: user_resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_resources (user_id, topic_id) FROM stdin;
\.
COPY public.user_resources (user_id, topic_id) FROM '$$PATH$$/3136.dat';

--
-- Data for Name: user_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_tests (id, test_id, user_id, status, acc_results, created, updated, questions_today, questions_day) FROM stdin;
\.
COPY public.user_tests (id, test_id, user_id, status, acc_results, created, updated, questions_today, questions_day) FROM '$$PATH$$/3138.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, surname, nickname, lang, initialized, created, updated, today_questions, average_questions, email, password, is_admin) FROM stdin;
\.
COPY public.users (id, name, surname, nickname, lang, initialized, created, updated, today_questions, average_questions, email, password, is_admin) FROM '$$PATH$$/3140.dat';

--
-- Name: paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paths_id_seq', 83, true);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.questions_id_seq', 288, true);


--
-- Name: resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.resources_id_seq', 8, true);


--
-- Name: table_name_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.table_name_id_seq', 1, false);


--
-- Name: tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tests_id_seq', 65, true);


--
-- Name: topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.topics_id_seq', 8, true);


--
-- Name: user_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_test_id_seq', 177, true);


--
-- Name: user_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_tests_id_seq', 27, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 240, true);


--
-- Name: paths paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paths
    ADD CONSTRAINT paths_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: tests tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (id);


--
-- Name: topics topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topics
    ADD CONSTRAINT topics_pkey PRIMARY KEY (topic_id);


--
-- Name: user_paths user_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paths
    ADD CONSTRAINT user_paths_pkey PRIMARY KEY (path_id, user_id);


--
-- Name: user_questions user_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_questions
    ADD CONSTRAINT user_questions_pkey PRIMARY KEY (question_id, user_id);


--
-- Name: user_resources user_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_resources
    ADD CONSTRAINT user_resources_pkey PRIMARY KEY (user_id, topic_id);


--
-- Name: user_tests user_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tests
    ADD CONSTRAINT user_tests_pkey PRIMARY KEY (id);


--
-- Name: user_tests user_tests_user_id_test_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tests
    ADD CONSTRAINT user_tests_user_id_test_id_key UNIQUE (user_id, test_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: questions questions_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.tests(id);


--
-- Name: questions questions_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(topic_id);


--
-- Name: resources resources_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.topics(topic_id);


--
-- Name: tests tests_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tests
    ADD CONSTRAINT tests_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.paths(id);


--
-- Name: user_paths user_paths_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paths
    ADD CONSTRAINT user_paths_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.paths(id);


--
-- Name: user_paths user_paths_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paths
    ADD CONSTRAINT user_paths_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_questions user_questions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_questions
    ADD CONSTRAINT user_questions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: user_questions user_questions_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_questions
    ADD CONSTRAINT user_questions_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.tests(id);


--
-- Name: user_questions user_questions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_questions
    ADD CONSTRAINT user_questions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_resources user_resources_resources_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_resources
    ADD CONSTRAINT user_resources_resources_id_fkey FOREIGN KEY (topic_id) REFERENCES public.resources(id);


--
-- Name: user_resources user_resources_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_resources
    ADD CONSTRAINT user_resources_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_tests user_tests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tests
    ADD CONSTRAINT user_tests_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.tests(id);


--
-- Name: user_tests user_tests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tests
    ADD CONSTRAINT user_tests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

